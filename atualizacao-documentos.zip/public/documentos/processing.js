// Browser-only Drive organization. Originals are never moved or removed.
let documentProcessing=false;
function organizationPath(doc){
  const company=companyById(doc.companyId);
  if(!company)throw new Error('Vincule uma empresa antes de processar.');
  if(!doc.verifiedAt)throw new Error('Confira e salve os dados do documento antes de processar.');
  let month=String(doc.competency||'').trim();
  if(/^\d{2}\/\d{4}$/.test(month))month=month.slice(3)+'-'+month.slice(0,2);
  if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))throw new Error('Informe a competência como MM/AAAA ou AAAA-MM na conferência.');
  const employee=data.employees.find(e=>e.id===doc.employeeId&&e.companyId===doc.companyId);
  if(doc.employeeId&&!employee)throw new Error('O funcionário precisa pertencer à empresa do documento.');
  if(doc.kind==='epi'&&!employee)throw new Error('Vincule o funcionário à ficha de EPI.');
  return ['Documentos empresas',company.name,month,...(doc.kind==='certificate'?['Certidões']:employee?['Funcionários',employee.name]:['Documentos contábeis'])];
}
async function organizationFolder(name,parent){
  const quote=value=>String(value).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  const query=`name = '${quote(name)}' and mimeType = 'application/vnd.google-apps.folder' and '${quote(parent)}' in parents and trashed = false`;
  const params=new URLSearchParams({q:query,fields:'files(id)',pageSize:'100'});
  const result=await driveRequest('https://www.googleapis.com/drive/v3/files?'+params).then(r=>r.json());
  if(result.files?.length)return result.files[0].id;
  const folder=await driveRequest('https://www.googleapis.com/drive/v3/files?fields=id',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,parents:[parent],mimeType:'application/vnd.google-apps.folder'})}).then(r=>r.json());
  return folder.id;
}
async function processDocument(docId){
  if(documentProcessing)return;
  if(!driveConnected){showToast('Conecte ou reconecte o Google Drive para processar.','error');return}
  const doc=data.documents.find(d=>d.id===docId);
  if(!doc?.driveFileId)return;
  documentProcessing=true;
  try{
    const path=organizationPath(doc);
    const signature=JSON.stringify(path);
    if(doc.organizedFileId&&doc.organizedSignature===signature){await persistDatabase();showToast('Este documento já está organizado.','success');return}
    let parent='root';
    for(const name of path)parent=await organizationFolder(name,parent);
    // Reconcile after an interrupted database write without duplicating the copy.
    const key=doc.driveFileId;
    const params=new URLSearchParams({q:`'${parent}' in parents and trashed = false and appProperties has { key='documentosSource' and value='${key.replace(/'/g,"\\'")}' }`,fields:'files(id,webViewLink)'});
    const existing=await driveRequest('https://www.googleapis.com/drive/v3/files?'+params).then(r=>r.json());
    const copy=existing.files?.[0]||await driveRequest('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(key)+'/copy?fields=id,webViewLink',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:doc.fileName,parents:[parent],appProperties:{documentosSource:key}})}).then(r=>r.json());
    Object.assign(doc,{organizedFileId:copy.id,organizedSignature:signature,organizedPath:path.join(' → '),organizedUrl:copy.webViewLink||'https://drive.google.com/file/d/'+encodeURIComponent(copy.id)+'/view',processedAt:new Date().toISOString()});
    await persistDatabase();renderPage();showToast('Cópia organizada em '+doc.organizedPath,'success');
  }catch(error){showToast(error.message||'Não foi possível processar. Reconecte o Drive e confira as permissões.','error')}
  finally{documentProcessing=false}
}
function previewDocument(docId){
  const doc=data.documents.find(d=>d.id===docId);
  if(!doc?.driveFileId)return;
  const fileId=encodeURIComponent(doc.driveFileId);
  openModal('Visualizar documento',doc.fileName||'Arquivo no Google Drive','<iframe class="document-preview" title="Visualização do arquivo no Google Drive" src="https://drive.google.com/file/d/'+fileId+'/preview" allow="fullscreen"></iframe><p>Se a visualização não carregar, abra o arquivo com uma conta que tenha acesso no Google Drive.</p><a class="button" href="https://drive.google.com/file/d/'+fileId+'/view" target="_blank" rel="noopener">Abrir no Drive</a>'+(doc.organizedPath?'<p>'+esc(doc.organizedPath)+'</p>':''));
}
document.addEventListener('click',event=>{
  const process=event.target.closest('[data-process]');if(process){processDocument(process.dataset.process);return}
  const preview=event.target.closest('[data-preview]');if(preview)previewDocument(preview.dataset.preview);
});
